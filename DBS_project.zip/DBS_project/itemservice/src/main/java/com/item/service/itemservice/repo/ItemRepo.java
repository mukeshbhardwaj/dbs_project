package com.item.service.itemservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.item.service.itemservice.model.OrderItem;

public interface ItemRepo extends JpaRepository<OrderItem, Integer>{

}
