package com.item.service.itemservice.service;

import org.springframework.stereotype.Service;

import com.item.service.itemservice.model.OrderItem;


@Service
public interface ItemService {

	public OrderItem saveItem(OrderItem name);

	public OrderItem getItem(int id);
}
