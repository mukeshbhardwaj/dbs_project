package com.item.service.itemservice.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.item.service.itemservice.model.OrderItem;
import com.item.service.itemservice.repo.ItemRepo;
import com.item.service.itemservice.service.ItemService;

@Service
public class ItemServiceImpl implements ItemService {
	@Autowired
	ItemRepo itemRepo;

	@Override
	public OrderItem saveItem(OrderItem name) {
		return itemRepo.save(name);

	}

	@Override
	public OrderItem getItem(int id) {
		Optional<OrderItem> p = itemRepo.findById(id);
		if (p.isPresent()) {
			
			OrderItem prod=p.get();
			return prod;
		} else {

			return null;
		}
	}

}
