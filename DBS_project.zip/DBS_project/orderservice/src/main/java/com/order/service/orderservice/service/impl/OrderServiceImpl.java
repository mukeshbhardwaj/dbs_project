package com.order.service.orderservice.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.order.service.orderservice.model.OrderDetail;
import com.order.service.orderservice.repo.OrderRepo;
import com.order.service.orderservice.service.OrderService;

@Service
public class OrderServiceImpl implements OrderService {
	@Autowired
	OrderRepo orderRepo;


	
	@Override
	public OrderDetail saveOrder(OrderDetail name) {
		return orderRepo.save(name);

	}

	@Override
	public OrderDetail getOrder(int id) {
		Optional<OrderDetail> p = orderRepo.findById(id);
		if (p.isPresent()) {
			
			OrderDetail prod=p.get();
			return prod;
		} else {

			return null;
		}
	}
}
