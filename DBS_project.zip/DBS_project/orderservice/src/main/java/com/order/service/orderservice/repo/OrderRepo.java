package com.order.service.orderservice.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.order.service.orderservice.model.OrderDetail;

public interface OrderRepo extends JpaRepository<OrderDetail, Integer> {

}
