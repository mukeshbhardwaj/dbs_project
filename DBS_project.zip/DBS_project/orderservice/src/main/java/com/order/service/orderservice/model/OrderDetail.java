package com.order.service.orderservice.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class OrderDetail {
	@Id
	private int orderId;
	private String customerName;
	private Date orderDate;
	private String shippingAddress;
	private String orderItemsName;
	private double price;

	public OrderDetail() {

	}

	public OrderDetail(int orderId, String customerName, Date orderDate, String shippingAddress, String orderItemsName,
			double price) {
		this.orderId = orderId;
		this.customerName = customerName;
		this.orderDate = orderDate;
		this.shippingAddress = shippingAddress;
		this.orderItemsName = orderItemsName;
		this.price = price;
	}

	public int getOrderId() {
		return orderId;
	}

	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public Date getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}

	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}

	public String getOrderItemsName() {
		return orderItemsName;
	}

	public void setOrderItemsName(String orderItemsName) {
		this.orderItemsName = orderItemsName;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
