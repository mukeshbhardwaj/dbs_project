package com.order.service.orderservice.ctrl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.order.service.orderservice.model.OrderDetail;
import com.order.service.orderservice.service.OrderService;

@RestController
@RequestMapping(value="/orders")
public class OrderController {

	@Autowired
	OrderService orderService;
	
	@PostMapping("/name")
	public ResponseEntity<OrderDetail> createOrder(@RequestBody OrderDetail order) {
		orderService.saveOrder(order);

		return ResponseEntity.status(201).body(order);

	}
	
	@GetMapping("/{id}")
	public ResponseEntity<OrderDetail> getOrderDetails(@PathVariable int id) {
		OrderDetail order = orderService.getOrder(id);

		return ResponseEntity.status(200).body(order);

	}
}
