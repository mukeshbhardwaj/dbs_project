package com.order.service.orderservice.service;

import org.springframework.stereotype.Service;

import com.order.service.orderservice.model.OrderDetail;

@Service
public interface OrderService {

	public OrderDetail saveOrder(OrderDetail name);

	public OrderDetail getOrder(int id);
	
}
